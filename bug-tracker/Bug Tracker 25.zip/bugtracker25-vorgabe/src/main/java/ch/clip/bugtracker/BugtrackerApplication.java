package ch.clip.bugtracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BugtrackerApplication {

	public static void main(String... args) {
		SpringApplication.run(BugtrackerApplication.class, args);

	}
}
