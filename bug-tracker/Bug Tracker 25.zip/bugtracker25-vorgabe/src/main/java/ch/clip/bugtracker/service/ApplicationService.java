package ch.clip.bugtracker.service;

import ch.clip.bugtracker.domain.Application;

import java.util.List;

public interface ApplicationService {
    List<Application> listApplications();

}


